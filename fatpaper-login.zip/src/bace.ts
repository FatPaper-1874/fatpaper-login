export const __MONOPOLYPAGEURL__ = "http://localhost:7000";
export const __USERSERVER__ = "http://localhost:8002";

